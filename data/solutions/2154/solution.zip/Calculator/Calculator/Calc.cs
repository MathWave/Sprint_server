﻿using System;
namespace Calculator
{
    public class Calc
    {
        public Calc()
        {
        }

        public static int Sum(int a, int b) => a + b;
    }
}
