﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Calculator
{
    class Calc
    {
        public static int Sum(int a, int b)
        {
            return a + b;
        }
    }
}
