﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Calculator
{
    public class Calc
    {
        public static int Sum(int a, int b)
        {
            return a + b;
        }
	public static int A() => 5;
    }
}
