using NUnit.Framework;
using Calculator;
using System.IO;

namespace TestProject2
{
    [TestFixture]
    public class Tests
    {
        [Test]
        public void Test1()
        {
            Assert.AreEqual(Calc.Sum(1, 1), 2);
        }

        [Test]
        public void Test2()
        {
            Assert.AreEqual(Calc.Sum(1, 1), 3);
        }

        [Test]
        public void Test3()
        {
            Assert.AreEqual(Calc.Sum(1, 0), 2);
        }
    }
}







// РєРѕРјРјРµРЅС‚Р°СЂРёР№ - РїР°СЃС…Р°Р»РєР°



